<?php
$lang['module_home'] = '首頁';

$lang['module_customers'] = '客戶';
$lang['module_customers_desc'] = '添加，更新，刪除，搜索客戶';

$lang['module_suppliers'] = '供應商';
$lang['module_suppliers_desc'] = '添加，更新，刪除，搜索供應商';

$lang['module_employees'] = '員工';
$lang['module_employees_desc'] = '添加，更新，刪除，搜索員工';

$lang['module_sales'] = '出貨';
$lang['module_sales_desc'] = '出貨與退貨';

$lang['module_reports'] = '報表';
$lang['module_reports_desc'] = '檢視與產生報表';

$lang['module_items'] = '產品';
$lang['module_items_desc'] = '添加，更新，刪除，搜索產品';

$lang['module_config'] = '系統配置';
$lang['module_config_desc'] = '修改系統配置';

$lang['module_receivings'] = '進貨';
$lang['module_receivings_desc'] = '採購訂單流程';

$lang['module_giftcards'] = '禮金券';
$lang['module_giftcards_desc'] = '添加，更新，刪除，搜索禮金券';

$lang['module_item_kits'] = '產品套件';
$lang['module_item_kits_desc'] = '添加，更新，刪除，搜索產品套件';

?>
