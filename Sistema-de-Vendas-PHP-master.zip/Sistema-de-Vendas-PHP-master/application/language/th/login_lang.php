<?php
$lang['login_login']='ลงชื่อเข้าใช้';
$lang['login_username']='ชื่อผู้ใช้';
$lang['login_password']='รหัสผ่าน';
$lang['login_go']='GOOOO';
$lang['login_invalid_username_and_password']='ชื่อผู้ใช้/รหัส ไม่ถูกต้อง';
$lang['login_welcome_message']='ยินดีต้องรับสู่ระบบ Open Source Point of Sale. เพื่อที่จะไปต่อ, กรุณาเข้าสู่ระบบโดยใส่ ชื่อผู้ใช้ และ รหัสผ่านที่อยู่ด้านล่าง.';
?>
<?php
$lang['login_login']='ลงชื่อเข้าใช้';
$lang['login_username']='ชื่อผู้ใช้';
$lang['login_password']='รหัสผ่าน';
$lang['login_go']='GOOOO';
$lang['login_invalid_username_and_password']='ชื่อผู้ใช้/รหัส ไม่ถูกต้อง';
$lang['login_welcome_message']='ยินดีต้องรับสู่ระบบ Open Source Point of Sale. เพื่อที่จะไปต่อ, กรุณาเข้าสู่ระบบโดยใส่ ชื่อผู้ใช้ และ รหัสผ่านที่อยู่ด้านล่าง.';
?>
