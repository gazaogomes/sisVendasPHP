<?php
$lang['module_home']='Home';

$lang['module_customers']='ลูกค้า';
$lang['module_customers_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา ลูกค้า';

$lang['module_suppliers']='ผู้ผลิต';
$lang['module_suppliers_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา ผู้ผลิต';

$lang['module_employees']='พนักงาน';
$lang['module_employees_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา พนักงาน';

$lang['module_sales']='งานขาย';
$lang['module_sales_desc']='งานขาย และ รับคืน';

$lang['module_reports']='รายงาน';
$lang['module_reports_desc']='สร้างและตรวจสอบรายงาน';

$lang['module_items']='สินค้า';
$lang['module_items_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา สินค้า';

$lang['module_config']='ปรับแต่งร้านค้า';
$lang['module_config_desc']='ปรับแต่งร้านค้า';

$lang['module_receivings']='สินค้าเข้า';
$lang['module_receivings_desc']='สินค้าเข้า';

$lang['module_giftcards']='กิ๊บการ์ด';
$lang['module_giftcards_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา กิ๊บการ์ด';

$lang['module_item_kits']='สินค้าหมู่';
$lang['module_item_kits_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา สินค้าหมู่';

?>
<?php
$lang['module_home']='Home';

$lang['module_customers']='ลูกค้า';
$lang['module_customers_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา ลูกค้า';

$lang['module_suppliers']='ผู้ผลิต';
$lang['module_suppliers_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา ผู้ผลิต';

$lang['module_employees']='พนักงาน';
$lang['module_employees_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา พนักงาน';

$lang['module_sales']='งานขาย';
$lang['module_sales_desc']='งานขาย และ รับคืน';

$lang['module_reports']='รายงาน';
$lang['module_reports_desc']='สร้างและตรวจสอบรายงาน';

$lang['module_items']='สินค้า';
$lang['module_items_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา สินค้า';

$lang['module_config']='ปรับแต่งร้านค้า';
$lang['module_config_desc']='ปรับแต่งร้านค้า';

$lang['module_receivings']='สินค้าเข้า';
$lang['module_receivings_desc']='สินค้าเข้า';

$lang['module_giftcards']='กิ๊บการ์ด';
$lang['module_giftcards_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา กิ๊บการ์ด';

$lang['module_item_kits']='สินค้าหมู่';
$lang['module_item_kits_desc']='เพิ่ม, อัพเดท, ลบ, และค้นหา สินค้าหมู่';

?>
