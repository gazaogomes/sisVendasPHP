Como instalar
-------------------------
1. Crie / localizar um novo banco de dados mysql para instalar ponto de código aberto de venda em
2. Execute o arquivo de banco de dados / database.sql para criar as tabelas necessárias
3. Descompacte o arquivo e fazer upload de código aberto Ponto de Venda arquivos para o servidor web
4. Aplicação copiar / config / database.php.tmpl para application / config / database.php
5. Modificar application / config / database.php para se conectar ao seu banco de dados
6. Modificar application / config / config.php chave de criptografia com seu próprio
7. Vá para o seu ponto de venda através do browser instalar
8. usando LOGIN
nome de usuário : admin
password: pointofsale
9. Aprecie


Desenvolvido por Glauber Funez
Fcaebook: http://facebook.com/glauber.funez
