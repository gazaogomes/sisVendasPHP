</div>
</div>
<div id="footer"> 
	<a href="http://www.webdesignjc.com">Web Design JC</a>
</div>
</body>
</html>