<?php
$lang['error_no_permission_module'] = '您沒有權限使用模組：';
$lang['error_unknown'] = '未知';
?>