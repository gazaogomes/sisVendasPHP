## ------------ discontinued -----------------

Este é um sistema de vendas completamente em php gratuito e pode ser modificado para o seu gosto.
Usuário : admin 
passar : 123
Este é um sistema de vendas de código php totalmente gratuito e pode ser modificado ao seu gosto
