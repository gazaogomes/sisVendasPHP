<?php
$lang['suppliers_new']='N. Leverancier';
$lang['suppliers_supplier']='Leverancier';
$lang['suppliers_update']='Bewerk Leverancier';
$lang['suppliers_confirm_delete']='Bent u zeker dat u de geselecteerde leveranciers wil verwijderen?';
$lang['suppliers_none_selected']='U hebt geen leveranciers geselecteerd';
$lang['suppliers_error_adding_updating'] = 'Fout bij het toevoegen/aanpassen van een leverancier';
$lang['suppliers_successful_adding']='Leverancier succesvol toegevoegd';
$lang['suppliers_successful_updating']='Wijzigingen leveranciersgegevens bewaard';
$lang['suppliers_successful_deleted']='Er werd(en)';
$lang['suppliers_one_or_multiple']='leverancier(s) verwijderd';
$lang['suppliers_cannot_be_deleted']='De geselecteeerde leveranciers konden niet worden verwijderd. Eén of meerdere leveranciers hebben ordergegevens in de database zitten.';
$lang['suppliers_basic_information']='Informatie Leverancier';
$lang['suppliers_account_number']='Btw nummer';
$lang['suppliers_company_name']='Bedrijfsnaam';
$lang['suppliers_company_name_required'] = 'Bedrijfsnaam moet ingevuld worden';
?>