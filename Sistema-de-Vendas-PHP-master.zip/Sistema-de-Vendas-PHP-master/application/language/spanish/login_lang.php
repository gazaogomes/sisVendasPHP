<?php
$lang['login_login']='Iniciar Sesión';
$lang['login_username']='Usuario';
$lang['login_password']='Password';
$lang['login_go']='Iniciar';
$lang['login_invalid_username_and_password']='Usuario/Contraseña inválidos';
$lang['login_welcome_message']='';
?>
