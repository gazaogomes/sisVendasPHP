<?php
$lang['login_login']='Login';
$lang['login_username']='Username';
$lang['login_password']='Password';
$lang['login_go']='Go';
$lang['login_invalid_username_and_password']='Invalid username/password';
$lang['login_welcome_message']='Welcome to the Open Source Point of Sale System. To continue, please login using your username and password below.';
?>
