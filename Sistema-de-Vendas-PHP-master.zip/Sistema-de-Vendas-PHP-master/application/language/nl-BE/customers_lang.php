<?php
$lang['customers_new']='Nieuwe Klant';
$lang['customers_customer']='Klant';
$lang['customers_update']='Bewerk Klant';
$lang['customers_confirm_delete']='Bent u zeker dat u de geselecteerde klanten wil verwijderen?';
$lang['customers_none_selected']='U hebt geen klanten geselecteerd';
$lang['customers_error_adding_updating'] = 'Fout bij het toevoegen/bewerken van een klant';
$lang['customers_successful_adding']='Klant succesvol aangemaakt';
$lang['customers_successful_updating']='Wijzigingen klantgegevens bewaard voor ';
$lang['customers_successful_deleted']='Er werd(en)';
$lang['customers_one_or_multiple']='klant(en) verwijderd';
$lang['customers_cannot_be_deleted']='De geselecteerde klanten konden niet worden verwijderd. Eén of meerdere klanten hebben verkoopsgegevens in de database zitten.';
$lang['customers_basic_information']='Klantgegevens';
$lang['customers_account_number']='Btwnummer';
$lang['customers_taxable']='Belastbaar';
?>